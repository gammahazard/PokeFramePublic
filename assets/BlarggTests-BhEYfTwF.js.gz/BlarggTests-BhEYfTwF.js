import{r as u,j as r,F as G,d}from"./index-BBtjCGTq.js";import{b as U,a as N,c as q,d as J,e as K,f as Q,g as V,h as X,i as Y,j as Z,k as ee,l as te,m as re,n as ae,o as oe,p as ne,q as se,r as ie,s as le,t as ge,u as me,v as ce,w as ue,x as de,y as be,z as pe,A as fe,B as he,C as _e,D as we,E as xe,F as ye,G as Re,H as ve,I as Ce,J as Ee,K as Se,L as ke,M as je,N as Ae,O as Te,T as Oe,U as Fe,V as Be,W as De,P as Ie,Q as We,R as $e,S as He,X as Le,Y as ze,Z as Me,_ as Pe,$ as Ge,a0 as Ue,a1 as Ne,a2 as qe,a3 as Je}from"./8-instr_effect-CUHNsoOc.js";import"./gb_web-ZP2ourm1.js";import{m as O,W as Ke,a as Qe}from"./gb_web_bg-DGoeA2lS.js";import"./__vite-plugin-wasm-helper-D7K_KhUE.js";const $=[{name:"gb-test-roms/cgb_sound/cgb_sound.gb",url:U},{name:"gb-test-roms/cgb_sound/rom_singles/01-registers.gb",url:N},{name:"gb-test-roms/cgb_sound/rom_singles/02-len ctr.gb",url:q},{name:"gb-test-roms/cgb_sound/rom_singles/03-trigger.gb",url:J},{name:"gb-test-roms/cgb_sound/rom_singles/04-sweep.gb",url:K},{name:"gb-test-roms/cgb_sound/rom_singles/05-sweep details.gb",url:Q},{name:"gb-test-roms/cgb_sound/rom_singles/06-overflow on trigger.gb",url:V},{name:"gb-test-roms/cgb_sound/rom_singles/07-len sweep period sync.gb",url:X},{name:"gb-test-roms/cgb_sound/rom_singles/08-len ctr during power.gb",url:Y},{name:"gb-test-roms/cgb_sound/rom_singles/09-wave read while on.gb",url:Z},{name:"gb-test-roms/cgb_sound/rom_singles/10-wave trigger while on.gb",url:ee},{name:"gb-test-roms/cgb_sound/rom_singles/11-regs after power.gb",url:te},{name:"gb-test-roms/cgb_sound/rom_singles/12-wave.gb",url:re},{name:"gb-test-roms/cpu_instrs/cpu_instrs.gb",url:ae},{name:"gb-test-roms/cpu_instrs/individual/01-special.gb",url:oe},{name:"gb-test-roms/cpu_instrs/individual/02-interrupts.gb",url:ne},{name:"gb-test-roms/cpu_instrs/individual/03-op sp,hl.gb",url:se},{name:"gb-test-roms/cpu_instrs/individual/04-op r,imm.gb",url:ie},{name:"gb-test-roms/cpu_instrs/individual/05-op rp.gb",url:le},{name:"gb-test-roms/cpu_instrs/individual/06-ld r,r.gb",url:ge},{name:"gb-test-roms/cpu_instrs/individual/07-jr,jp,call,ret,rst.gb",url:me},{name:"gb-test-roms/cpu_instrs/individual/08-misc instrs.gb",url:ce},{name:"gb-test-roms/cpu_instrs/individual/09-op r,r.gb",url:ue},{name:"gb-test-roms/cpu_instrs/individual/10-bit ops.gb",url:de},{name:"gb-test-roms/cpu_instrs/individual/11-op a,(hl).gb",url:be},{name:"gb-test-roms/dmg_sound/dmg_sound.gb",url:pe},{name:"gb-test-roms/dmg_sound/rom_singles/01-registers.gb",url:fe},{name:"gb-test-roms/dmg_sound/rom_singles/02-len ctr.gb",url:he},{name:"gb-test-roms/dmg_sound/rom_singles/03-trigger.gb",url:_e},{name:"gb-test-roms/dmg_sound/rom_singles/04-sweep.gb",url:we},{name:"gb-test-roms/dmg_sound/rom_singles/05-sweep details.gb",url:xe},{name:"gb-test-roms/dmg_sound/rom_singles/06-overflow on trigger.gb",url:ye},{name:"gb-test-roms/dmg_sound/rom_singles/07-len sweep period sync.gb",url:Re},{name:"gb-test-roms/dmg_sound/rom_singles/08-len ctr during power.gb",url:ve},{name:"gb-test-roms/dmg_sound/rom_singles/09-wave read while on.gb",url:Ce},{name:"gb-test-roms/dmg_sound/rom_singles/10-wave trigger while on.gb",url:Ee},{name:"gb-test-roms/dmg_sound/rom_singles/11-regs after power.gb",url:Se},{name:"gb-test-roms/dmg_sound/rom_singles/12-wave write while on.gb",url:ke},{name:"gb-test-roms/halt_bug.gb",url:je},{name:"gb-test-roms/instr_timing/instr_timing.gb",url:Ae},{name:"gb-test-roms/interrupt_time/interrupt_time.gb",url:Te},{name:"gb-test-roms/mem_timing/individual/01-read_timing.gb",url:Oe},{name:"gb-test-roms/mem_timing/individual/02-write_timing.gb",url:Fe},{name:"gb-test-roms/mem_timing/individual/03-modify_timing.gb",url:Be},{name:"gb-test-roms/mem_timing/mem_timing.gb",url:De},{name:"gb-test-roms/mem_timing-2/mem_timing.gb",url:Ie},{name:"gb-test-roms/mem_timing-2/rom_singles/01-read_timing.gb",url:We},{name:"gb-test-roms/mem_timing-2/rom_singles/02-write_timing.gb",url:$e},{name:"gb-test-roms/mem_timing-2/rom_singles/03-modify_timing.gb",url:He},{name:"gb-test-roms/oam_bug/oam_bug.gb",url:Le},{name:"gb-test-roms/oam_bug/rom_singles/1-lcd_sync.gb",url:ze},{name:"gb-test-roms/oam_bug/rom_singles/2-causes.gb",url:Me},{name:"gb-test-roms/oam_bug/rom_singles/3-non_causes.gb",url:Pe},{name:"gb-test-roms/oam_bug/rom_singles/4-scanline_timing.gb",url:Ge},{name:"gb-test-roms/oam_bug/rom_singles/5-timing_bug.gb",url:Ue},{name:"gb-test-roms/oam_bug/rom_singles/6-timing_no_bug.gb",url:Ne},{name:"gb-test-roms/oam_bug/rom_singles/7-timing_effect.gb",url:qe},{name:"gb-test-roms/oam_bug/rom_singles/8-instr_effect.gb",url:Je}];async function Ve(m){try{const h=await fetch(m,{method:"GET",headers:{"Cache-Control":"max-age=31536000"},cache:"force-cache"});if(!h.ok)throw new Error(`Failed to fetch ${m}: ${h.status} ${h.statusText}`);const v=await h.arrayBuffer();return new Uint8Array(v)}catch(h){throw console.error(`Error fetching bytes from ${m}:`,h),h}}const Xe=d.div`
  display: flex;
  flex-direction: column;
  padding: 20px;
  background: linear-gradient(180deg, #3a539b 0%, #1c295d 100%);
  color: white;
  min-height: 100vh;
`,Ye=d.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
`,Ze=d.h1`
  font-size: 24px;
  margin: 0;
`,et=d.button`
  padding: 8px 16px;
  background-color: #ffcb05;
  color: #3a539b;
  border: none;
  border-radius: 4px;
  font-weight: bold;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #ffd74d;
  }
`,tt=d.div`
  display: flex;
  flex-direction: row;
  gap: 20px;

  @media (max-width: 768px) {
    flex-direction: column;
  }
`,rt=d.div`
  flex: 1;
  min-width: 300px;
  max-width: 400px;
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  padding: 15px;

  @media (max-width: 768px) {
    max-width: 100%;
  }
`,at=d.div`
  flex: 2;
  display: flex;
  flex-direction: column;
  gap: 15px;
`,ot=d.div`
  height: 60vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 5px;

  &::-webkit-scrollbar {
    width: 8px;
  }

  &::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 4px;
  }

  &::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 4px;
  }
`,nt=d.button`
  text-align: left;
  padding: 8px 12px;
  background-color: ${({selected:m})=>m?"rgba(255, 203, 5, 0.8)":"rgba(255, 255, 255, 0.1)"};
  color: ${({selected:m})=>m?"#3a539b":"white"};
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.2s;
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;

  &:hover {
    background-color: ${({selected:m})=>m?"rgba(255, 203, 5, 0.9)":"rgba(255, 255, 255, 0.2)"};
  }
`,st=d.div`
  background-color: rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  padding: 15px;
  display: flex;
  flex-direction: column;
  align-items: center;
`,it=d.div`
  background-color: #9bbc0f; /* Classic GameBoy screen color */
  width: 160px;
  height: 144px;
  image-rendering: pixelated;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
  margin-bottom: 15px;
`,lt=d.div`
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
`,y=d.button`
  padding: 6px 12px;
  background-color: #3a539b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.2s;

  &:hover {
    background-color: #4c6bc6;
  }
`,gt=d.div`
  font-family: monospace;
  background-color: #222;
  color: #0f0;
  padding: 10px;
  border-radius: 4px;
  white-space: pre-wrap;
  word-break: break-all;
  height: 150px;
  overflow-y: auto;
  width: 100%;
  margin-top: 10px;
`,mt=d.div`
  display: flex;
  align-items: center;
  gap: 5px;
  margin-top: 10px;
  font-weight: bold;
  color: ${({passed:m})=>m===null?"#ffcb05":m?"#0f0":"#f00"};
`;function ft(){const[m,h]=u.useState(null),[v,F]=u.useState(!1),[a,B]=u.useState(null),[C,D]=u.useState(""),[E,S]=u.useState(null),[I,_]=u.useState(!1),[w,k]=u.useState(null),H=u.useCallback(e=>{if(e!==null){console.log("Canvas element mounted and reference assigned"),k(e);const t=e.getContext("2d");t&&(t.fillStyle="#9bbc0f",t.fillRect(0,0,e.width,e.height),t.fillStyle="#000",t.font="14px monospace",t.textAlign="center",t.fillText("SELECT A TEST ROM",e.width/2,e.height/2-10),t.font="10px monospace",t.fillText("from the list on the left",e.width/2,e.height/2+10),t.imageSmoothingEnabled=!1)}else console.log("Canvas element unmounted"),k(null)},[]),l=u.useRef(null),j=u.useCallback(async e=>{F(!0),D(""),S(null);try{a&&L(),window.memory=O;const t=$.find(o=>o.name===e)?.url;if(!t)throw new Error(`ROM not found: ${e}`);const g=await Ve(t);if(console.log(`ROM loaded: ${e}, ${g.length} bytes`),!w){console.error("Canvas reference is not available. Waiting for it to be created...");const o=document.getElementById("blargg-test-canvas");if(o)console.log("Found canvas element by ID"),k(o);else if(await new Promise(i=>setTimeout(i,1e3)),!w&&!document.getElementById("blargg-test-canvas"))throw new Error("Canvas reference still not available after waiting")}const n=w||document.getElementById("blargg-test-canvas");if(!n)throw new Error("Could not find canvas element");const b=n.getContext("2d");if(!b)throw new Error("Could not get canvas context");b.fillStyle="#9bbc0f",b.fillRect(0,0,n.width,n.height),b.fillStyle="#000",b.font="10px monospace",b.textAlign="center",b.fillText("LOADING TEST ROM...",n.width/2,n.height/2);const W=new Ke(g);console.log("Cartridge created successfully");let s;try{s=new Qe(W,()=>{}),console.log("Successfully created new emulator instance");try{if(typeof s.set_capture_serial=="function")s.set_capture_serial(!0),console.log("Set serial capture successfully using standard method");else{console.log("Standard serial capture not available, implementing custom solution");const o=[],i=s.hw?.write_byte;s.serialOutput=o,typeof i=="function"?(s.hw.write_byte=function(c,f){const x=typeof c=="string"?parseInt(c,16):c;if(x===65281)o.push(String.fromCharCode(f)),console.log(`Serial data written: ${String.fromCharCode(f)} (${f})`);else if(x===65282&&(f&128)===128)try{if(this.read_byte){const p=this.read_byte(65281);o.push(String.fromCharCode(p)),console.log(`Serial transfer started, data: ${String.fromCharCode(p)} (${p})`)}}catch{}return i.call(this,c,f)},s.get_serial_output=function(){return o.join("")},console.log("Successfully implemented custom serial capture")):console.warn("Could not patch write_byte method, serial output may not work")}}catch(o){console.warn("Could not set up serial capture:",o),s.get_serial_output=function(){return""}}}catch(o){throw console.error("Failed to create emulator instance:",o),new Error("Failed to initialize emulator. Please try a different ROM.")}if(!s)throw new Error("Emulator initialization failed");console.log("Running initial frames to initialize emulator...");for(let o=0;o<15;o++)s.run_frame();typeof s.get_serial_output!="function"&&(s.serialOutput||(s.serialOutput=[]),s.get_serial_output=function(){return Array.isArray(this.serialOutput)?this.serialOutput.join(""):""},console.log("Added fallback get_serial_output method"));try{const o=s.get_canvas_data_pointer();if(o&&o>0&&b){console.log("Drawing initial frame from pointer:",o);const i=160,c=144,f=b.createImageData(i,c),x=new Uint8Array(O.buffer,o,i*c*3);for(let p=0;p<i*c;p++){const T=p*3;f.data[p*4]=x[T],f.data[p*4+1]=x[T+1],f.data[p*4+2]=x[T+2],f.data[p*4+3]=255}b.putImageData(f,0,0),(n.width!==i||n.height!==c)&&(b.imageSmoothingEnabled=!1,b.drawImage(b.canvas,0,0,i,c,0,0,n.width,n.height))}}catch(o){console.warn("Error drawing initial frame:",o)}B(s),h(e)}catch(t){console.error("Error initializing emulator:",t)}finally{F(!1)}},[a,w]),L=u.useCallback(()=>{l.current&&(cancelAnimationFrame(l.current),l.current=null),_(!1),B(null)},[]),R=u.useCallback(()=>{if(!a)return;const e=w||document.getElementById("blargg-test-canvas");if(!e){console.error("Cannot find canvas element for rendering");return}try{a.run_frame();const t=a.get_canvas_data_pointer();if(t&&t>0){const n=e.getContext("2d");if(n){const s=n.createImageData(160,144),o=new Uint8Array(O.buffer,t,160*144*3);for(let i=0;i<160*144;i++){const c=i*3;s.data[i*4]=o[c],s.data[i*4+1]=o[c+1],s.data[i*4+2]=o[c+2],s.data[i*4+3]=255}if(n.putImageData(s,0,0),e.width!==160||e.height!==144){const i=document.createElement("canvas");i.width=160,i.height=144;const c=i.getContext("2d");c&&(c.putImageData(s,0,0),n.clearRect(0,0,e.width,e.height),n.imageSmoothingEnabled=!1,n.drawImage(i,0,0,160,144,0,0,e.width,e.height))}}}let g="";try{typeof a.get_serial_output=="function"?g=a.get_serial_output():(console.warn("get_serial_output method missing - recovering"),a.get_serial_output||(a.serialOutput||(a.serialOutput=[]),a.get_serial_output=function(){return Array.isArray(this.serialOutput)?this.serialOutput.join(""):""},console.log("Recreated get_serial_output method")),typeof a.get_serial_output=="function"&&(g=a.get_serial_output()))}catch(n){console.warn("Error reading serial output:",n),a.serialOutput&&Array.isArray(a.serialOutput)&&(g=a.serialOutput.join(""))}g&&g!==C&&(console.log("Serial output updated:",g),D(g),g.includes("Passed")?(console.log("🎉 TEST PASSED! 🎉"),S(!0),_(!1),l.current&&(cancelAnimationFrame(l.current),l.current=null)):g.includes("Failed")&&(console.log("❌ TEST FAILED! ❌"),S(!1),_(!1),l.current&&(cancelAnimationFrame(l.current),l.current=null)))}catch(t){console.error("Error in runFrame:",t)}},[a,C,w]),z=u.useCallback(()=>{if(!a){console.error("Cannot run emulator: No emulator instance available");return}console.log("Starting emulator animation loop"),l.current&&(cancelAnimationFrame(l.current),l.current=null),_(!0);const e={},t=a,g=()=>{try{if(!t){console.log("Animation stopped: emulator no longer available");return}R(),e===l.current?requestAnimationFrame(g):console.log("Animation loop was replaced or canceled")}catch(n){console.error("Error in animation loop:",n),_(!1),l.current===e&&(l.current=null)}};l.current=e,requestAnimationFrame(g)},[a,R]),A=u.useCallback(()=>{l.current&&(cancelAnimationFrame(l.current),l.current=null),_(!1)},[]),M=u.useCallback(()=>{m&&(A(),j(m))},[m,A,j]);u.useEffect(()=>()=>{l.current&&(cancelAnimationFrame(l.current),l.current=null),console.log("Component unmounting - cleanup complete")},[]),u.useEffect(()=>(console.log("BlarggTests component mounted"),()=>{console.log("BlarggTests component unmounted")}),[]);const P=$.reduce((e,t)=>{const n=t.name.split("/")[1];return e[n]||(e[n]=[]),e[n].push(t),e},{});return r.jsxs(Xe,{children:[r.jsxs(Ye,{children:[r.jsx(Ze,{children:"Blargg Test ROMs"}),r.jsx(et,{onClick:()=>window.location.href="/",children:"Back to Games"})]}),r.jsxs(tt,{children:[r.jsxs(rt,{children:[r.jsx("h3",{children:"Test ROM Categories"}),r.jsx(ot,{children:Object.entries(P).map(([e,t])=>r.jsxs("div",{children:[r.jsx("h4",{children:e}),t.map(g=>r.jsx(nt,{selected:m===g.name,onClick:()=>j(g.name),children:g.name.split("/").pop()},g.name))]},e))})]}),r.jsx(at,{children:r.jsx(st,{children:v?r.jsx(G,{style:{width:"160px",height:"144px"}}):r.jsxs(r.Fragment,{children:[r.jsx(it,{children:r.jsx("canvas",{ref:H,width:"320",height:"288",id:"blargg-test-canvas",style:{width:"100%",height:"100%",imageRendering:"pixelated",WebkitImageRendering:"-webkit-optimize-contrast",WebkitFontSmoothing:"none"}})}),r.jsxs(lt,{children:[r.jsx(y,{onClick:z,disabled:!a||I,children:"Run"}),r.jsx(y,{onClick:A,disabled:!a||!I,children:"Pause"}),r.jsx(y,{onClick:M,disabled:!m,children:"Reset"}),r.jsx(y,{onClick:()=>{a&&R()},disabled:!a,children:"Step Frame"}),r.jsx(y,{onClick:()=>{if(a){for(let e=0;e<100;e++)a.run_frame();R(),console.log("Ran 100 frames")}},disabled:!a,children:"Run 100 Frames"})]}),E!==null&&r.jsx(mt,{passed:E,children:r.jsx("span",{children:E?"✅ TEST PASSED":"❌ TEST FAILED"})}),r.jsx("h3",{children:"Serial Output"}),r.jsx(gt,{children:C||"(No output yet)"})]})})})]})]})}export{ft as default};
